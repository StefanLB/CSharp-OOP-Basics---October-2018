﻿using System;
using System.Collections.Generic;
using System.Text;

public class RaceTower
{
    void SetTrackInfo(int lapsNumber, int trackLength)
    {
        //TODO: Add some logic here …
    }
    void RegisterDriver(List<string> commandArgs)
    {
        //TODO: Add some logic here …
    }

    void DriverBoxes(List<string> commandArgs)
    {
        //TODO: Add some logic here …
    }

    string CompleteLaps(List<string> commandArgs)
    {
        //TODO: Add some logic here …
        throw new NotImplementedException();
    }

    string GetLeaderboard()
    {
        //TODO: Add some logic here …
        throw new NotImplementedException();
    }

    void ChangeWeather(List<string> commandArgs)
    {
        //TODO: Add some logic here …
    }
}
